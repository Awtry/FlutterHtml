package com.example.app_api_res

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
