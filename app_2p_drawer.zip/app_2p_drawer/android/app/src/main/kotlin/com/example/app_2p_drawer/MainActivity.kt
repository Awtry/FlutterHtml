package com.example.app_2p_drawer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
