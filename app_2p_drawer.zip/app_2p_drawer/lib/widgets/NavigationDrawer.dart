import 'package:flutter/material.dart';
import 'package:app_2p_drawer/pages/firstPage.dart';
import 'package:app_2p_drawer/pages/SecondPage.dart';

class NavigationDrawer extends StatefulWidget {
  const NavigationDrawer({ Key? key }) : super(key: key);

  //@override
  //_NavigationDrawerState createState() => NavigationDrawer();
}